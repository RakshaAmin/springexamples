package com.spring.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInterceptorHandlerConceptApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInterceptorHandlerConceptApplication.class, args);
	}

}
