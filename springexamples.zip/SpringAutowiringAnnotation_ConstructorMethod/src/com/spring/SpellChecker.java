package com.spring;

public class SpellChecker {
	
	public SpellChecker()
	{
		System.out.println("inside spell checker constructor");
	}


public void SpellCheckerMy()
{
	System.out.println("From spellcheck SpellCheckerMy method");
}



}
