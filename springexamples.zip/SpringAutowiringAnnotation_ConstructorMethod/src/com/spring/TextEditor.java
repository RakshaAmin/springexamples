package com.spring;

import org.springframework.beans.factory.annotation.Autowired;

public class TextEditor {
	
	public SpellChecker spellChecker;
	
	@Autowired
	public TextEditor(SpellChecker spellChecker) {
		System.out.println("constructor from TextEditor");
	}

	public SpellChecker getSpellChecker() {
		return spellChecker;
	}

	public void setSpellChecker(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}

public void SpellChk()
{
	spellChecker.SpellCheckerMy();
}
}
