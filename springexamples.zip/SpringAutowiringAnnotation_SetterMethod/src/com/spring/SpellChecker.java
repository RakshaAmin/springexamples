package com.spring;


public class SpellChecker {
	
	public SpellChecker()
	{
		
		
		System.out.println("inside  SpellChecker constructor");
		
	}


public void checkSpelling() {
		
		System.out.println("inside  SpellChecker method");
	}

}
