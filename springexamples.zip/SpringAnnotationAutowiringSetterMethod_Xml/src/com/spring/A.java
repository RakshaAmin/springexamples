package com.spring;

public class A {

	B b;
	
	private String name="ram";
	
	public A()
	{
		System.out.println("from class A");
	}
	
	public A(B b) {
	
		this.b=b;
		
	}
	
	
	public B getB() {
		return b;
	}
	public void setB(B b) {
		this.b = b;
	}
	void print()
	{
		System.out.println("print() from A");

	}
	public void show() {
		print();
		b.print();
	}

}
