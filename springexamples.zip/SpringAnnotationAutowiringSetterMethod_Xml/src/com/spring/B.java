package com.spring;

public class B {
	
	public B() {
		System.out.println("form B is created");
		
	}
	public void print() {
		
		
		System.out.println("from hello B");
		
	}

}
