package com.spring;

public class Student {
	
	
	
	private String studentname;

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	
		
	
	public void showStudentInfo() {

		
		System.out.println("name of student"+studentname);
	}
	

}
