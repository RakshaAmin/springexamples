package com.spring;

import java.util.List;

public interface EmployeeDao {
	 
	    public Employee findEmployeeById(int empId);
	    
	    
	    public List<Employee> findAllEmployees();
}